/**
 * @author ubaldo
 */
function saluda() {
    alert("Hola Mundo");
}

function escribeMensaje() {
    document.getElementById("mensajeHtml").innerHTML = "Saludo desde archivo de JavaScript";
}
